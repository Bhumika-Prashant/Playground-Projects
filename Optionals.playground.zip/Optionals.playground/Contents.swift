import UIKit

var myName: String?

myName?.uppercased()    // its not an empty string but its nil -> not even initialized yet
//myName!.uppercased()    // I am sure user has initialized name

var myString = ""   // empty string -> its already initialized

var myAge = "5"
var myInteger = Int(myAge)! * 5     // Force unwrapping -> 5 is an Integer

//var myAge1 = "Apple"
//var myInteger1 = Int(myAge1)! * 5   // Force unwrapping -> crash because Apple is not an Integer

var myAge1 = "Apple"
var myInteger1 = (Int(myAge1) ?? 0) * 5     // Nil-Coalescing

if let myNumber = Int(myAge1) {     // Optional Binding
    print(myNumber * 5)
} else {
    print("Wrong input")
}
